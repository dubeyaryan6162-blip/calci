const display = document.getElementById('display');

function appendValue(value) {
    display.value += value;
}

function clearDisplay() {
    display.value = '';
}

function calculate() {
    try {
        // eval is used here for simplicity in this basic example
        display.value = eval(display.value);
    } catch (error) {
        display.value = 'Error';
    }
}
